from os import name

from django.urls import path, include

from customer import views

from customer.views import ReportePersonalizadoExcel


urlpatterns = [
    path('list-customer/', views.ListCustomer.as_view()),
    # path('list-customer-filtro/', views.ListCustomerFiltro.as_view()), #Agregado solo muestra nombre, fecha, estatus 100621
    path('list-customer-filtro/', views.ListCustomerFiltro), #Agregado solo muestra nombre, fecha, estatus 100621
    
    path('customer/<int:idCliente>/', views.CustomerDetail.as_view()),
    path('list-country/', views.ListCountry.as_view()),
    path('list-estates/<int:idPais>/', views.ListEstates.as_view()),
    path('list-empresa/', views.ListEmpresas.as_view()),
    path('list-usocfdi/', views.ListUsoCfdi.as_view()),
    path('list-formapago/', views.ListFormaPago.as_view()),
    path('list-metodopago/', views.ListMetodoPago.as_view()),
    path('list-areas/', views.ListAreas.as_view()),
    #ruta para el listado de contacto Ismael 260521
    path('list-contacts/<int:idCliente>/', views.ListContacts.as_view()),
    path('contac-details/<int:idContact>/', views.ContactDetail.as_view()),
    # path('contac-details/<int:idContact>/', views.ContactDetail.as_view()),
    path('customer/addFiles/', views.addFiles),
    # path('','customer/addFiles/', views.addFiles), //original
    #listado de los archivos ismael 250521
    path('list-files/<int:idCliente>/', views.ListFiles.as_view()),
    path('consultaFiles/', views.consultarFiles),
    path('files-details/<int:idFile>/', views.DetailsFiles.as_view()),
    path('list-datacomplementary/<int:idCliente>/', views.ListDataComplementary.as_view()), 
    # path('datacomplementary-details/<int:idFile>/', views.DataComplementaryDetail.as_view()),
    path('list-business/', views.ListBusiness.as_view()),
    path('list-ladas/', views.ListLada.as_view()),     
    # //===
    path('customer/showpDF/', views.showpDF),
    # path('customer/', views.CustomersViewSet.as_view()),
    # path('new-add/', views.ListAreas.as_view()),
    path('list-rutas/<int:idCliente>/', views.ListRutas.as_view()), 
    path('search-zipcode/', views.searchZIP), 

    # path('search-customer/', views.searchCustomer),  #130621
    # path('senEmail/', views.TestView.as_view(), name='test'), 
    path('senEmail/', views.send_email),

    path('list-pdf/', views.PDFCustomer.as_view(), name='pdf'), #Generar PDF
    path('list-excel/', views.ReportePersonalizadoExcel.as_view(), name = 'reporte_excel'), #Generar Excel

    
]