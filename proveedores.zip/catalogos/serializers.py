from django.db.models import fields
from rest_framework import serializers

from .models import Producto, UnitBox, Customs, ClaveProdServ, ClaveUnidad, Producto, Servicio, Puesto, Responsable, Envio

class SerializerUnitBox(serializers.ModelSerializer): #Agregado David 310521
    id = serializers.IntegerField(read_only=True)
    class Meta:
        model = UnitBox
        fields = '__all__'

class UnitBoxSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(read_only=True)
    class Meta:
        model = UnitBox
        fields = '__all__'

class CustomsSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(read_only=True)
    class Meta:
        model = Customs
        fields = '__all__'

class ClaveProdServSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(read_only=True)
    class Meta:
        model = ClaveProdServ
        fields = '__all__'

class ClaveUnidadSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(read_only=True)
    class Meta:
        model = ClaveUnidad
        fields = '__all__'

class ProductoSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(read_only=True)
    class Meta:
        model = Producto
        fields = '__all__'

class ServicioSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(read_only=True)
    class Meta:
        model = Servicio
        fields = '__all__'

class PuestoSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(read_only=True)
    class Meta:
        model = Puesto
        fields = '__all__'

class ResponsableSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(read_only=True)
    class Meta:
        model = Responsable
        fields = '__all__'

class EnvioSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(read_only=True)
    class Meta:
        model = Envio
        fields = '__all__'