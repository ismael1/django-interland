from django.shortcuts import render
from rest_framework import viewsets
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.decorators import api_view
from django.views.decorators.csrf import csrf_exempt

from django.db.models.query_utils import Q
from django.db.models import Count

from .models import Envio, UnitBox, Customs, ClaveProdServ, ClaveUnidad, Producto, Servicio, Puesto, Responsable, Envio
from .serializers import SerializerUnitBox, UnitBoxSerializer, CustomsSerializer, ClaveProdServSerializer, ClaveUnidadSerializer, ProductoSerializer, ServicioSerializer, PuestoSerializer, ResponsableSerializer, EnvioSerializer

class UnitBoxtViewSet(viewsets.ModelViewSet):
    queryset = UnitBox.objects.all()
    serializer_class = UnitBoxSerializer

class  ClaveProdServViewSet(viewsets.ModelViewSet):
    queryset = ClaveProdServ.objects.all()
    serializer_class = ClaveProdServSerializer

class ClaveUnidadViewSet(viewsets.ModelViewSet):
    queryset = ClaveUnidad.objects.all()
    serializer_class = ClaveUnidadSerializer

class ProductoViewSet(viewsets.ModelViewSet):
    queryset = Producto.objects.all()
    serializer_class = ProductoSerializer

class ServicioViewSet(viewsets.ModelViewSet):
    queryset = Servicio.objects.all()
    serializer_class = ServicioSerializer

class PuestoViewSet(viewsets.ModelViewSet):
    queryset = Puesto.objects.all()
    serializer_class = PuestoSerializer

class ResponsableViewSet(viewsets.ModelViewSet):
    queryset = Responsable.objects.all()
    serializer_class = ResponsableSerializer

class EnvioViewSet(viewsets.ModelViewSet):
    queryset = Envio.objects.all()
    serializer_class = EnvioSerializer


@csrf_exempt
@api_view(['POST','GET'])
def listBox(request):
    dato = request.data.get('data')

    if dato:
        box = UnitBox.objects.filter(modalidad__contains=dato)
        serializer = SerializerUnitBox(box, many=True)
        return Response(serializer.data)
    else:
        return Response({"no result": []})


@csrf_exempt 
@api_view(['POST', 'GET'])
def searchAduana(request):
    dato = request.data.get('data')
    if dato:
        aduana = Customs.objects.filter(Q(origen__icontains=dato) | Q(destino__icontains=dato))
        # que=str(servicio.query)
        # print(que)
        serializer = CustomsSerializer(aduana, many=True)
        return Response(serializer.data)
    else:
        return Response({"no result": []})


@csrf_exempt 
@api_view(['POST', 'GET'])
def getNameAduana(request):
    dato = request.data.get('data')
    if dato:
        aduana = Customs.objects.get(id=dato)
        # que=str(servicio.query)
        # print(que)
        serializer = CustomsSerializer(aduana)
        return Response(serializer.data)
    else:
        return Response({"no result": []})

@csrf_exempt
@api_view(['GET'])
def ListProductoFiltro(request):

        page = int(request.GET.get('page', 1))
        size = int(request.GET.get('size', 1))
        palabra=str(request.GET.get('palabra', 1))
        data_start = (page - 1) * size
        data_end = page * size

        if (palabra == ""):
            goodslist=Producto.objects.filter(Q(estatus=0))[data_start:data_end]
            count=Producto.objects.filter(Q(estatus=0)).count()
        else:
            goodslist = Producto.objects.filter(Q(nombreProductoServicios__icontains=palabra) | Q(unidad__icontains=palabra)).filter(Q(estatus=0))[data_start:data_end]
            count=Producto.objects.filter(Q(nombreProductoServicios__icontains=palabra) | Q(unidad__icontains=palabra)).filter(Q(estatus=0))[data_start:data_end].count()

        red = str(goodslist.query)
        print (red)

        goods_ser=ProductoSerializer(goodslist,many=True)

        return Response({
            'total':count,
            'data':goods_ser.data
        })

@csrf_exempt
@api_view(['GET'])
def ListServicioFiltro(request):

        page = int(request.GET.get('page', 1))
        size = int(request.GET.get('size', 1))
        palabra=str(request.GET.get('palabra', 1))
        data_start = (page - 1) * size
        data_end = page * size

        if (palabra == ""):
            goodslist=Servicio.objects.filter(Q(estatus=0))[data_start:data_end]
            count=Servicio.objects.filter(Q(estatus=0)).count()
        else:
            goodslist = Servicio.objects.filter(Q(nombreProductoServicios__icontains=palabra) | Q(duracion__icontains=palabra) | Q(tiempo__icontains=palabra)).filter(Q(estatus=0))[data_start:data_end]
            count=Servicio.objects.filter(Q(nombreProductoServicios__icontains=palabra) | Q(duracion__icontains=palabra) | Q(tiempo__icontains=palabra)).filter(Q(estatus=0))[data_start:data_end].count()

        goods_ser=ServicioSerializer(goodslist,many=True)

        return Response({
            'total':count,
            'data':goods_ser.data
        })

@csrf_exempt
@api_view(['GET'])
def ListClaveFiltro(request):

        page = int(request.GET.get('page', 1))
        size = int(request.GET.get('size', 1))
        palabra=str(request.GET.get('palabra', 1))
        data_start = (page - 1) * size
        data_end = page * size

        if (palabra == ""):
            goodslist=ClaveProdServ.objects.filter(Q(estatus=0))[data_start:data_end]
            count=ClaveProdServ.objects.filter(Q(estatus=0)).count()
        else:
            goodslist = ClaveProdServ.objects.filter(Q(clave_prodserv__icontains=palabra) | Q(descripcion__icontains=palabra)).filter(Q(estatus=0))[data_start:data_end]
            count=ClaveProdServ.objects.filter(Q(clave_prodserv__icontains=palabra) | Q(descripcion__icontains=palabra)).filter(Q(estatus=0))[data_start:data_end].count()

        goods_ser=ClaveProdServSerializer(goodslist,many=True)

        return Response({
            'total':count,
            'data':goods_ser.data
        })
        
@csrf_exempt
@api_view(['GET'])
def ListClaveUnidadFiltro(request):

        page = int(request.GET.get('page', 1))
        size = int(request.GET.get('size', 1))
        palabra=str(request.GET.get('palabra', 1))
        data_start = (page - 1) * size
        data_end = page * size

        if (palabra == ""):
            goodslist=ClaveUnidad.objects.filter(Q(estatus=0))[data_start:data_end]
            count=ClaveUnidad.objects.filter(Q(estatus=0)).count()
        else:
            goodslist = ClaveUnidad.objects.filter(Q(claveUnidad__icontains=palabra) | Q(nombre__icontains=palabra) | Q(descripcion__icontains=palabra) | Q(nota__icontains=palabra)).filter(Q(estatus=0))[data_start:data_end]
            count=ClaveUnidad.objects.filter(Q(claveUnidad__icontains=palabra) | Q(nombre__icontains=palabra) | Q(descripcion__icontains=palabra) | Q(nota__icontains=palabra)).filter(Q(estatus=0))[data_start:data_end].count()

        goods_ser=ClaveUnidadSerializer(goodslist,many=True)

        return Response({
            'total':count,
            'data':goods_ser.data
        })

@csrf_exempt
@api_view(['GET'])
def ListPuestoFiltro(request):
        page = int(request.GET.get('page', 1))
        size = int(request.GET.get('size', 1))
        palabra = str(request.GET.get('palabra', 1))
        data_start = (page - 1) * size
        data_end = page * size
        if (palabra == ""):
            goodslist=Puesto.objects.filter(Q(estatus=0))[data_start:data_end]
            count=Puesto.objects.filter(Q(estatus=0)).count()
        else:
            goodslist = Puesto.objects.filter(Q(nombre__icontains=palabra) | Q(tipo__icontains=palabra) | Q(descripcion__icontains=palabra)).filter(Q(estatus=0))[data_start:data_end]
            count = Puesto.objects.filter(Q(nombre__icontains=palabra) | Q(tipo__icontains=palabra) | Q(descripcion__icontains=palabra)).filter(Q(estatus=0))[data_start:data_end].count()
        goods_ser=PuestoSerializer(goodslist,many=True)
        return Response({
            'total':count,
            'data':goods_ser.data
        })

@csrf_exempt
@api_view(['GET'])
def ListResponsableFiltro(request):
        page = int(request.GET.get('page', 1))
        size = int(request.GET.get('size', 1))
        palabra = str(request.GET.get('palabra', 1))
        data_start = (page - 1) * size
        data_end = page * size
        if (palabra == ""):
            goodslist = Responsable.objects.filter(Q(estatus=0))[data_start:data_end]
            count = Responsable.objects.filter(Q(estatus=0)).count()
        else:
            goodslist = Responsable.objects.filter(Q(nombre__icontains=palabra) | Q(apellidos__icontains=palabra)).filter(Q(estatus=0))[data_start:data_end]
            count = Responsable.objects.filter(Q(nombre__icontains=palabra) | Q(apellidos__icontains=palabra)).filter(Q(estatus=0))[data_start:data_end].count()
        goods_ser=ResponsableSerializer(goodslist,many=True)
        return Response({
            'total':count,
            'data':goods_ser.data
        })

@csrf_exempt
@api_view(['GET'])
def ListEnvioFiltro(request):
        page = int(request.GET.get('page', 1))
        size = int(request.GET.get('size', 1))
        palabra = str(request.GET.get('palabra', 1))
        data_start = (page - 1) * size
        data_end = page * size
        if (palabra == ""):
            goodslist = Envio.objects.filter(Q(estatus=0))[data_start:data_end]
            count = Envio.objects.filter(Q(estatus=0)).count()
        else:
            goodslist = Envio.objects.filter(Q(nombre__icontains=palabra)).filter(Q(estatus=0))[data_start:data_end]
            count = Envio.objects.filter(Q(nombre__icontains=palabra)).filter(Q(estatus=0))[data_start:data_end].count()
        goods_ser = EnvioSerializer(goodslist,many=True)
        return Response({
            'total':count,
            'data':goods_ser.data
        })

@csrf_exempt 
@api_view(['POST', 'GET'])
def searchPS(request):
    dato = request.data.get('data')

    if dato:
        busqueda = ClaveProdServ.objects.values('clave_prodserv','descripcion').filter(clave_prodserv__icontains=dato).annotate(total=Count('clave_prodserv'))
        serializer = ClaveProdServSerializer(busqueda, many=True)
        return Response(serializer.data)
    else:
        return Response({"no result": []})

@csrf_exempt 
@api_view(['POST', 'GET'])
def searchUnit(request):
    dato = request.data.get('data')

    if dato:
        busqueda = ClaveUnidad.objects.values('claveUnidad','nombre').filter(claveUnidad__icontains=dato.replace(" ", ""))
        # red = str(busqueda.query)
        # print (red)
        serializer = ClaveUnidadSerializer(busqueda, many=True)
        return Response(serializer.data)
    else:
        return Response({"no result": []})