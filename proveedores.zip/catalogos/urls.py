from os import name
from django.urls import path, include
from catalogos import views

urlpatterns = [
    path('list-box/', views.listBox),   
    path('search-aduana/', views.searchAduana),
    path('get-aduana/', views.getNameAduana),

    path('list-producto-filtro/', views.ListProductoFiltro),
    path('list-servicio-filtro/', views.ListServicioFiltro),
    path('list-clave-filtro/', views.ListClaveFiltro),
    path('list-clave-unidad-filtro/', views.ListClaveUnidadFiltro),
    path('list-puesto-filtro/', views.ListPuestoFiltro),
    path('list-responsable-filtro/', views.ListResponsableFiltro),
    path('list-envio-filtro/', views.ListEnvioFiltro),

    path('search-proser/', views.searchPS), 
    path('search-unidad/', views.searchUnit), 
]