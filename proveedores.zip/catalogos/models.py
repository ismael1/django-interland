from django.db import models
from django.db.models.base import Model


class UnitBox(models.Model):
    code = models.CharField(max_length=20, blank=True, null=True)
    name = models.CharField(max_length=30, blank=True, null=True)
    code_name = models.CharField(max_length=40, blank=True, null=True)
    order_cot = models.CharField(max_length=30, blank=True, null=True)
    description = models.CharField(max_length=120, blank=True, null=True)
    peso_bruto_carga = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    peso_bruto_total = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    capacidad_vol = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    long = models.CharField(max_length=30, blank=True, null=True)
    width = models.CharField(max_length=30, blank=True, null=True)
    high = models.CharField(max_length=30, blank=True, null=True)
    orderg = models.CharField(max_length=30, blank=True, null=True)
    orderp = models.CharField(max_length=30, blank=True, null=True)
    modalidad =  models.CharField(max_length=20, blank=True, null=True)

    class Meta:
        ordering = ('name',)

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return f'/{self.name}/'


class Customs(models.Model):
    origen = models.CharField(max_length=100, blank=True, null=True)
    destino = models.CharField(max_length=100, blank=True, null=True)
    pais = models.CharField(max_length=5, blank=True, null=True)

    class Meta:
        ordering = ('pais',)

    def __str__(self):
        return self.pais

    def get_absolute_url(self):
        return f'/{self.pais}/'

class ClaveProdServ(models.Model):
    clave_prodserv = models.CharField(max_length=20, blank=True, null=True, default=0)
    descripcion = models.CharField(max_length=120, blank=True, null=True, default="")
    fechaInicioVigencia = models.DateField(blank=True, null=True, default=0)
    fechaFinVigencia = models.DateField(blank=True, null=True, default=0)
    ivaTraslado = models.CharField(max_length=12, blank=True, null=True, default="")
    iepsTraslado = models.CharField(max_length=12, blank=True, null=True, default="")
    complementoIncluir = models.CharField(max_length=12, blank=True, null=True, default="")
    dateCreate = models.DateTimeField(auto_now_add=True)
    estatus = models.IntegerField(blank=True, null=True, default=0)

class ClaveUnidad(models.Model):
    claveUnidad = models.CharField(max_length=20, blank=True, null=True, default=0)
    nombre = models.CharField(max_length=100, blank=True, null=True, default="")
    descripcion = models.CharField(max_length=120, blank=True, null=True, default="")
    nota = models.CharField(max_length=420, blank=True, null=True, default="" )
    fechaInicioVigencia = models.DateField(blank=True, null=True, default=0)
    fechaFinVigencia = models.DateField(blank=True, null=True, default=0)
    dateCreate = models.DateTimeField(auto_now_add=True)
    simbolo = models.CharField(max_length=40, blank=True, default=True)
    estatus = models.IntegerField(blank=True, null=True, default=0)

class Producto(models.Model):
    claveProductoServicio = models.CharField(max_length=50, blank=True, null=True, default=0)
    nombreProductoServicios = models.CharField(max_length=300, blank=True, null=True, default=0)
    unidad = models.IntegerField(blank=True, null=True, default=0)
    claveUnidad = models.CharField(max_length=300, blank=True, null=True, default=0)
    numeroIdentificacion = models.IntegerField(blank=True, null=True, default=True)
    # estadoVentas = models.BooleanField(blank=True, null=True, default=False)
    # estadoCompras = models.BooleanField(blank=True, null=True, default=False)
    descripcion = models.CharField(max_length=100, blank=True, null=True, default="")
    # naturaleza = models.CharField(max_length=50, blank=True, null=True, default="")
    # peso = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True, default=0)
    # pesoName = models.CharField(max_length=12, blank=True, null=True, default="")
    # longitud = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True, default=0)
    # longitudName = models.CharField(max_length=12, blank=True, null=True, default="")
    # superficie = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True, default=0)
    # superficieName = models.CharField(max_length=12, blank=True, null=True, default="")
    # volumen = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True, default=0)
    # volumenName = models.CharField(max_length=12, blank=True, null=True, default="")
    # codigoAduanero = models.IntegerField(blank=True, null=True, default=0)
    # paisOrigen = models.CharField(max_length=100, blank=True, null=True)
    # idPaisOrigen = models.IntegerField(blank=True, null=True, default=0)
    # nota = models.CharField(max_length=100, blank=True, null=True, default="")
    # precioVenta = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True, default=0)
    # precioVentaName = models.CharField(max_length=12, blank=True, null=True, default="")
    # precioVentaMin = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True, default=0)
    divisaCompra = models.IntegerField(blank=True, null=True, default=0)
    tasaDivisaCompra = models.IntegerField(blank=True, null=True, default=0)
    tasaRetencionCompra = models.IntegerField(blank=True, null=True, default=0)
    divisaVenta = models.IntegerField(blank=True, null=True, default=0)
    tasaIvaVenta = models.IntegerField(blank=True, null=True, default=0)
    tasaRetencionVenta = models.IntegerField(blank=True, null=True, default=0)
    dateCreate = models.DateTimeField(auto_now_add=True)
    estatus = models.IntegerField(blank=True, null=True, default=0)

class Servicio(models.Model):
    claveProductoServicio = models.CharField(max_length=50, blank=True, null=True, default=0)
    nombreProductoServicios = models.CharField(max_length=300, blank=True, null=True, default="")
    unidad = models.IntegerField(blank=True, null=True, default=0)
    claveUnidad = models.CharField(max_length=300, blank=True, null=True, default=0)
    numeroIdentificacion = models.IntegerField(blank=True, null=True, default=True)
    # estadoVentas = models.BooleanField(blank=True, null=True, default=False)
    # estadoCompras = models.BooleanField(blank=True, null=True, default=False)
    descripcion = models.CharField(max_length=100, blank=True, null=True, default="")
    # duracion = models.CharField(max_length=20, blank=True, null=True, default="")
    # tiempo = models.CharField(max_length=20, blank=True, null=True, default="")
    # codigoAduanero = models.IntegerField(blank=True, null=True, default=0)
    # paisOrigen = models.CharField(max_length=100, blank=True, null=True)
    # idPaisOrigen = models.IntegerField(blank=True, null=True, default=0)
    # nota = models.CharField(max_length=100, blank=True, null=True, default="")
    # precioVenta = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True, default=0)
    # precioVentaName = models.CharField(max_length=12, blank=True, null=True, default="")
    # precioVentaMin = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True, default=0)
    divisaCompra = models.IntegerField(blank=True, null=True, default=0)
    tasaDivisaCompra = models.IntegerField(blank=True, null=True, default=0)
    tasaRetencionCompra = models.IntegerField(blank=True, null=True, default=0)
    divisaVenta = models.IntegerField(blank=True, null=True, default=0)
    tasaIvaVenta = models.IntegerField(blank=True, null=True, default=0)
    tasaRetencionVenta = models.IntegerField(blank=True, null=True, default=0)
    dateCreate = models.DateTimeField(auto_now_add=True)
    estatus = models.IntegerField(blank=True, null=True, default=0)

class Puesto(models.Model):
    nombre = models.CharField(max_length=120, blank=True, null=True, default="")
    tipo = models.CharField(max_length=15, blank=True, null=True, default="")
    descripcion = models.CharField(max_length=120, blank=True, null=True, default="")
    dateCreate = models.DateTimeField(auto_now_add=True)
    estatus = models.IntegerField(blank=True, null=True, default=0)

class Responsable(models.Model):
    nombre = models.CharField(max_length=40, blank=True, null=True, default="")
    apellidos = models.CharField(max_length=40, blank=True, null=True, default="")
    dateCreate = models.DateTimeField(auto_now_add=True)
    estatus = models.IntegerField(blank=True, null=True, default=0)

class Envio(models.Model):
    nombre = models.CharField(max_length=20, blank=True, null=True)
    dateCreate = models.DateTimeField(auto_now_add=True)
    estatus = models.IntegerField(blank=True, null=True, default=0)