from setuptools import setup

setup(
    name='xframeoptions',
    version='0.1dev',
    packages=['xframeoptions']
)
