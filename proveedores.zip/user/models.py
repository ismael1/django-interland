from django.db import models

# Create your models here.


# class User(models.Model):
#     username = models.CharField(max_length=100, blank=True, null=True)
#     nameproduct = models.CharField(max_length=30, blank=True, null=True)
#     unit = models.CharField(max_length=15, blank=True, null=True)
#     codeunit = models.CharField(max_length=20, blank=True, null=True)
#     type = models.CharField(max_length=20, blank=True, null=True)
#     description = models.CharField(max_length=30, blank=True, null=True)