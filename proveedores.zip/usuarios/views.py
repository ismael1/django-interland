from django.shortcuts import render
from rest_framework import serializers, viewsets
from rest_framework.permissions import OR
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.decorators import api_view
from django.views.decorators.csrf import csrf_exempt

# from rest_framework_api_key.permissions import HasAPIKey
from django.db.models.query_utils import Q
from django.db.models import Count

from .models import Usuarios
from .serializers import UsuariosSerializer

class UsuariosViewSet(viewsets.ModelViewSet):
    queryset = Usuarios.objects.all()
    serializer_class = UsuariosSerializer

@csrf_exempt
@api_view(['GET'])
def ListUsuarios(request):
        page = int(request.GET.get('page', 1))
        size = int(request.GET.get('size', 1))
        palabra = str(request.GET.get('palabra', 1))
        data_start = (page - 1) * size
        data_end = page * size
        if (palabra == ""):
            goodslist = Usuarios.objects.filter(Q(estatus=1))[data_start:data_end]
            count = Usuarios.objects.filter(Q(estatus=1)).count()
        else:
            goodslist = Usuarios.objects.filter(Q(nombre__icontains=palabra) | Q(apellidos__icontains=palabra)).filter(Q(estatus=1))[data_start:data_end]
            count = Usuarios.objects.filter(Q(nombre__icontains=palabra) | Q(apellidos__icontains=palabra)).filter(Q(estatus=1))[data_start:data_end].count()
        goods_ser=UsuariosSerializer(goodslist,many=True)
        return Response({
            'total':count,
            'data':goods_ser.data
        })

@csrf_exempt 
@api_view(['POST'])
def ValidaUsuario(request):

    ape = request.data.get('apellidos')
    nom = request.data.get('nombre')
    logi = request.data.get('login')
    pss = request.data.get('pass')
    mail = request.data.get('email')
    
    # fecha_hoy= 2021-07-13
    # select * from servicos_venata  where fecha_vigencia >  fecha_hoy

    # __lte Se utiliza para fechas -> equivalente a fechaFin <= fecha hoy
    # __gte Se utiliza para fechas -> equivalente a fechaFin >= fecha hoy

    if (ape == Usuarios.apellidos | nom == Usuarios.nombre):
        # relacionar = ServicioVenta.objects.filter(paisOrigen=paisOri).filter(estadoOrigen=estadoOri).filter(ciudadOrigen=ciudadOri).filter(paisDestino=paisDes).filter(estadoDestino=estadoDes).filter(ciudadDestino=ciudadDes).filter(unidaModality=tipoCarga).filter(tipoUnidad_id=tipoUnidad).filter(dateFin__gte=fechaFin).filter(checkVentas="SI").order_by('-id')[:3]
        # relacionar = Usuarios.objects.filter(apellidos=ape).filter(nombre=nom).filter(login=logi).filter(password=pss).filter(email=mail).count()
        relacionar = Usuarios.objects.filter(apellidos=ape).filter(nombre=nom)
        count = Usuarios.objects.filter(apellidos=ape).filter(nombre=nom).count()
        red = str(relacionar.query)
        print (red)
        # serializer = UsuariosSerializer(relacionar, many=True)
        return Response({
            'total':count,
        })
    else:
        count = Usuarios.objects.filter(Q(login=logi) | Q(password=pss) | Q(email=mail)).count()
        return Response({
            'total': count,
        })

@csrf_exempt 
@api_view(['POST'])
def ValidUser(request):

    email = request.data.get('email')
    passw = request.data.get('password')

    if email :
        relacionar = Usuarios.objects.filter(email=email).filter(password=passw)
        serializer = UsuariosSerializer(relacionar, many=True)
        red = str(relacionar.query)
        print (red)
        return Response(serializer.data)
    else:
        return Response({"no result": []})

# @csrf_exempt 
# @api_view(['POST'])
# def ServiceCoincidencia(request):

#     paisOri = request.data.get('paisOrigen')
#     estadoOri = request.data.get('estadoOrigen')
#     ciudadOri = request.data.get('ciudadOrigen')
#     paisDes = request.data.get('paisDestino')
#     estadoDes = request.data.get('estadoDestino')
#     ciudadDes = request.data.get('ciudadDestino')
#     fechaFin = request.data.get('dateFin')
#     tipoCarga = request.data.get('unidaModality')
#     tipoUnidad = request.data.get('tipoUnidad_id')

#     if paisOri:
#         relacionar = ServicioVenta.objects.filter(paisOrigen=paisOri).filter(estadoOrigen=estadoOri).filter(ciudadOrigen=ciudadOri).filter(paisDestino=paisDes).filter(estadoDestino=estadoDes).filter(ciudadDestino=ciudadDes).filter(unidaModality=tipoCarga).filter(tipoUnidad_id=tipoUnidad).filter(dateFin__gte=fechaFin).filter(checkVentas="SI").order_by('-id')[:3]
#         red = str(relacionar.query)
#         print (red)
#         serializer = FiltroServiceSerializer(relacionar, many=True)
#         return Response(serializer.data)
#     else:
#         return Response({"no result": []})