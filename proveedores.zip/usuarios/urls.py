from os import name
from django.urls import path, include
from usuarios import views

urlpatterns = [
    path('list-user-filtro/', views.ListUsuarios),
    path('validar-usuario/', views.ValidaUsuario),
    path('valida/', views.ValidUser),
]