from os import name

from django.urls import path, include

from cotizaciones import views

urlpatterns = [

    path('list-services-coincidencia/', views.ServiceCoincidencia),
    path('list-cotizacion-filtro/', views.ListCotizacionFiltro),
    # path('list-cotizacion-filtro/', views.ListCotizacionFiltro),
    path('service-filtro/', views.ServicePrice),
    path('consultar-servicios-agregados/', views.ConsultarServiciosAgregados),
    path('consultar-contacto-agregado/', views.ConsultarContactoAgregado),

    path('consultar-folio/', views.ConsultarFolio.as_view()),
    path('cotiza-pdf/', views.PDFCotizacion.as_view(), name='pdf'), #Generar PDF
]