from servicioVenta.serializers import FiltroServiceSerializer
from django.shortcuts import render



from rest_framework import viewsets
from rest_framework.authentication import BasicAuthentication
from rest_framework.permissions import IsAuthenticated

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.decorators import api_view
from django.views.decorators.csrf import csrf_exempt

from django.db.models.query_utils import Q

#Generar PDF Librerias Necesarias Agregado David
from django.template.loader import render_to_string
import os
from django.views.generic import ListView, View 
from django.conf import settings
from django.http import HttpResponse
from django.template.loader import get_template
from xhtml2pdf import context, pisa
from django.contrib.staticfiles import finders
#Fin Librerias PDF Necesarias

#Nueva Llibreria PDF
# from weasyprint import HTML
#Fi Libreria PDF

import datetime

from servicioVenta.serializers import ServicioVenta
from .models import ServicioCotizacion, ContactoCotizacion, ServiciosAgregadosCotizacion
from .serializers import FiltroServicioCotizacion, SerializerServicioCotizacion, SerializerContactoCotizacion, SerializerServiciosAgregadosCotizacion

class ServicioCotizaciones(viewsets.ModelViewSet):
    queryset = ServicioCotizacion.objects.all()
    serializer_class = SerializerServicioCotizacion

class ServiciosAgregadosCotizaciones(viewsets.ModelViewSet):
    queryset = ServiciosAgregadosCotizacion.objects.all()
    serializer_class = SerializerServiciosAgregadosCotizacion

class ContactoCotizaciones(viewsets.ModelViewSet):
    queryset = ContactoCotizacion.objects.all()
    serializer_class = SerializerContactoCotizacion

@csrf_exempt 
@api_view(['POST'])
def ServiceCoincidencia(request):

    paisOri = request.data.get('paisOrigen')
    estadoOri = request.data.get('estadoOrigen')
    ciudadOri = request.data.get('ciudadOrigen')
    paisDes = request.data.get('paisDestino')
    estadoDes = request.data.get('estadoDestino')
    ciudadDes = request.data.get('ciudadDestino')
    fechaFin = request.data.get('dateFin')
    tipoCarga = request.data.get('unidaModality')
    tipoUnidad = request.data.get('tipoUnidad_id')
    
    # fecha_hoy= 2021-07-13
    # select * from servicos_venata  where fecha_vigencia >  fecha_hoy

    # __lte Se utiliza para fechas -> equivalente a fechaFin <= fecha hoy
    # __gte Se utiliza para fechas -> equivalente a fechaFin >= fecha hoy

    if paisOri:
        relacionar = ServicioVenta.objects.filter(paisOrigen=paisOri).filter(estadoOrigen=estadoOri).filter(ciudadOrigen=ciudadOri).filter(paisDestino=paisDes).filter(estadoDestino=estadoDes).filter(ciudadDestino=ciudadDes).filter(unidaModality=tipoCarga).filter(tipoUnidad_id=tipoUnidad).filter(dateFin__gte=fechaFin).filter(checkVentas="SI").order_by('-id')[:3]
        # red = str(relacionar.query)
        # print (red)
        serializer = FiltroServiceSerializer(relacionar, many=True)
        return Response(serializer.data)
    else:
        return Response({"no result": []})

@csrf_exempt
@api_view(['GET'])
def ListCotizacionFiltro(request):

        page = int(request.GET.get('page', 1))
        size = int(request.GET.get('size', 1))
        palabra=str(request.GET.get('palabra', 1))
        data_start = (page - 1) * size
        data_end = page * size

        if (palabra == ""):
            goodslist=ServicioCotizacion.objects.filter(Q(estatus=0)| Q(estatus=1) | Q(estatus=2))[data_start:data_end]
            count=ServicioCotizacion.objects.filter(Q(estatus=0)| Q(estatus=1) | Q(estatus=2)).count()
        else:
            goodslist = ServicioCotizacion.objects.filter(Q(tipoServicio__icontains=palabra) | Q(folio__icontains=palabra)).filter(Q(estatus=0)| Q(estatus=1) | Q(estatus=2))[data_start:data_end]
            count=ServicioCotizacion.objects.filter(Q(tipoServicio__icontains=palabra) | Q(folio__icontains=palabra)).filter(Q(estatus=0)| Q(estatus=1) | Q(estatus=2))[data_start:data_end].count()

        goods_ser=FiltroServicioCotizacion(goodslist,many=True)

        return Response({
            'total':count,
            'data':goods_ser.data
        })

# Consultar Folio
class ConsultarFolio(APIView):
    def get(self, request, format=None):
        buscarFolio = ServicioCotizacion.objects.latest('folio')
        serializer = FiltroServicioCotizacion(buscarFolio)
        return Response(serializer.data)

@csrf_exempt 
@api_view(['POST'])
def ServicePrice(request):
    
    nombreServicio = request.data.get('servicio')

    if nombreServicio:
        buscar = ServicioVenta.objects.filter(servicio=nombreServicio).order_by('-id')[0:1]
        # red = str(buscar.query)
        # print (red)
        serializer = FiltroServiceSerializer(buscar, many=True)
        return Response(serializer.data)
    else:
        return Response({"no result": []})

# Consultar Servicios Agregados
@csrf_exempt 
@api_view(['POST'])
def ConsultarServiciosAgregados(request):
    
    servicios = request.data.get('idcotizacion')

    if servicios:
        buscarServicios = ServiciosAgregadosCotizacion.objects.filter(idcotizacion=servicios)
        # red = str(buscarServicios.query)
        # print (red)
        serializer = SerializerServiciosAgregadosCotizacion(buscarServicios, many=True)
        return Response(serializer.data)
    else:
        return Response({"no result": []})

# Consultar Contacto Agregado
@csrf_exempt 
@api_view(['POST'])
def ConsultarContactoAgregado(request):
    
    contacto = request.data.get('idcotizacion')

    if contacto:
        buscarServicios = ContactoCotizacion.objects.filter(idcotizacion=contacto)
        # red = str(buscarServicios.query)
        # print (red)
        serializer = SerializerContactoCotizacion(buscarServicios, many=True)
        return Response(serializer.data)
    else:
        return Response({"no result": []})

# GENERAR PDF Prueba 1
# class PDFCotizacion(APIView):
#     def get(self, request, *args, **kwargs):
#         cotiza = ServicioCotizacion.objects.filter(id=15)        
#         serializer = FiltroServicioCotizacion(cotiza, many=True)
#         # return Response(serializer.data)
#         # template = get_template('pdf/customers.html')
#         template = render_to_string('pdf/cotizacionPDF.html', {'ServicioCotizacion': serializer.data})   
#         # print(template)
#         # context = {'title': 'Lista Clientes PDF'}
#         # html = template.render(context)
#         html = template
#         response = HttpResponse(content_type= 'application/pdf')
#         response['Content-Disposition'] = 'attachment; filename="Cotizacion.pdf"'
#         pisa_status = pisa.CreatePDF(html, dest = response)
#         if pisa_status.err:
#             return HttpResponse('We had some errors <pre>' + html + '</pre>')
#         return response


# GENERAR PDF Prueba 2 WeasyPrint
class PDFCotizacion(View):

    # def link_callback(self, request, *args, **kwargs):
    #     sUrl = settings.STATIC_URL
    #     sRoot = settings.STATIC_ROOT
    #     mUrl = settings.MEDIA_URL
    #     mRoot = settings.MEDIA_ROOT
    #     return os.path

    def get(self, request, *args, **kwargs):
        ids=27
        # ids=3

        # context = {
        #     'icon': '{}{}'.format(settings.STATIC_URL, '/media/img/logo_i.png')
        # }
        
        cotiza = ServicioCotizacion.objects.filter(id=ids)
        coti = serializer = FiltroServicioCotizacion(cotiza, many=True)

        service = ServiciosAgregadosCotizacion.objects.filter(idcotizacion_id=ids)
        serv = serializer = SerializerServiciosAgregadosCotizacion(service, many=True)

        contact = ContactoCotizacion.objects.filter(idcotizacion_id=ids)
        cont = serializer = SerializerContactoCotizacion(contact, many=True)        

        html= template = render_to_string('pdf/cotizacionPDF.html', {'ServicioCotizacion': coti.data, 'ServiciosAgregadosCotizacion': serv.data, 'ContactoCotizacion': cont.data }) 
        # html= template = render_to_string('pdf/cotizacionPDF.html', {'ServicioCotizacion': coti.data, 'ServiciosAgregadosCotizacion': serv.data, 'ContactoCotizacion': cont.data }, context) 
        # template = render_to_string('pdf/cotizacionPDF.html', {'ServicioCotizacion': serializer.data}, {'ServiciosAgregadosCotizacion': serializer.data}) 
        html = template
        response = HttpResponse(content_type= 'application/pdf')
        pisa_status = pisa.CreatePDF(html, dest=response)
        # pisa_status = pisa.CreatePDF(html, dest=response, link_callback=self.link_callback)
        if pisa_status.err:
            return HttpResponse('We had some errors <pre>' + html + '</pre>')
        return response