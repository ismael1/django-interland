from django.db.models import fields
from rest_framework import serializers

from .models import ServicioCotizacion, ContactoCotizacion, ServiciosAgregadosCotizacion

class SerializerServicioCotizacion(serializers.ModelSerializer):
    id = serializers.IntegerField(read_only=True)
    # dateCreate = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S")
    class Meta:
        model = ServicioCotizacion
        fields = '__all__'

class SerializerServiciosAgregadosCotizacion(serializers.ModelSerializer):
    id = serializers.IntegerField(read_only=True)
    # dateCreate = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S")
    class Meta:
        model = ServiciosAgregadosCotizacion
        fields = '__all__'

class SerializerContactoCotizacion(serializers.ModelSerializer):
    id = serializers.IntegerField(read_only=True)
    # dateCreate = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S")
    class Meta:
        model = ContactoCotizacion
        fields = '__all__'

class FiltroServicioCotizacion(serializers.ModelSerializer):
    id = serializers.IntegerField(read_only=True)
    # dateCreate = serializers.DateTimeField(format="%Y-%m-%d %H:%M:%S")

    class Meta:
        model = ServicioCotizacion
        fields = '__all__'