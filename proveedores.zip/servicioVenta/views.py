from cotizaciones.models import ServicioCotizacion, ServiciosAgregadosCotizacion
from cotizaciones.serializers import SerializerServicioCotizacion, SerializerServiciosAgregadosCotizacion

from django.http.response import Http404
from django.shortcuts import render
from .models import ServicioVenta
from .serializers import SerializerServicioVenta,FiltroServiceSerializer

from rest_framework import viewsets
from rest_framework.authentication import BasicAuthentication
from rest_framework.permissions import IsAuthenticated

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.decorators import api_view
from django.views.decorators.csrf import csrf_exempt

from django.db.models.query_utils import Q


# Create your views here.
class ServicioVentas(viewsets.ModelViewSet):
    authentication_classes = (BasicAuthentication,)
    permission_classes = (IsAuthenticated,)
    queryset = ServicioVenta.objects.all()
    serializer_class = SerializerServicioVenta


@csrf_exempt 
@api_view(['GET'])
def ListServiceFiltro(request):

        page = int(request.GET.get('page', 1))
        size = int(request.GET.get('size', 1))
        palabra=str(request.GET.get('palabra', 1))
        data_start = (page - 1) * size
        data_end = page * size

        if (palabra == ""):
            # goodslist=ServicioVenta.objects.filter(estatusCompleto=0)[data_start:data_end]
            goodslist=ServicioVenta.objects.order_by('id').filter(estatusCompleto=0)[data_start:data_end]
            count=ServicioVenta.objects.filter(estatusCompleto=0).count()
        else:   
            palabra_min=palabra.lower()
            palabra_may=palabra.upper()
            goodslist = ServicioVenta.objects.order_by('id').objects.filter(Q(servicio__icontains=palabra) | Q(servicio__icontains=palabra)).filter(estatusCompleto=0)[data_start:data_end]
            count=ServicioVenta.objects.filter(Q(servicio__icontains=palabra) | Q(servicio__icontains=palabra)).filter(estatusCompleto=0)[data_start:data_end].count()
        goods_ser=FiltroServiceSerializer(goodslist,many=True)

        return Response({
            'total':count,
            'data':goods_ser.data
        })

@csrf_exempt 
@api_view(['GET'])
def ListServiceFiltroIncompleto(request):

        page = int(request.GET.get('page', 1))
        size = int(request.GET.get('size', 1))
        palabra=str(request.GET.get('palabra', 1))
        data_start = (page - 1) * size
        data_end = page * size

        if (palabra == ""): 
            goodslist = ServicioVenta.objects.order_by('id').filter(estatusCompleto=3)[data_start:data_end]
            count=ServicioVenta.objects.filter(estatusCompleto=3).count()
        else:
            goodslist = ServicioVenta.objects.objects.order_by('id').filter(Q(servicio__icontains=palabra) | Q(servicio__icontains=palabra)).filter(estatusCompleto=3)[data_start:data_end]
            count=ServicioVenta.objects.filter(Q(servicio__icontains=palabra) | Q(servicio__icontains=palabra)).filter(estatusCompleto=3)[data_start:data_end].count()

        goods_ser=FiltroServiceSerializer(goodslist,many=True)

        return Response({
            'total':count,
            'data':goods_ser.data
        })


#agregado
@csrf_exempt 
@api_view(['GET'])
def ListService(request):       
    goodslist=ServicioVenta.objects.all()
    goods_ser=FiltroServiceSerializer(goodslist,many=True)
    return Response(goods_ser.data)


class ServiceSaleDetail(APIView):    
    
    def get_object(self, idServicio):
        try:
            return ServicioVenta.objects.get(id=idServicio)
        except ServicioVenta.DoesNotExist:
            return Http404
    
    def get(self, request, idServicio, format=None):
        
        servicio = self.get_object(idServicio)
        serializer = SerializerServicioVenta(servicio)
        return Response(serializer.data)

@csrf_exempt 
@api_view(['POST'])
def ConsultarCotizacionAgregada(request):
    
    venta = request.data.get('idVenta')

    if venta:
        buscarServicios = ServicioCotizacion.objects.filter(idVenta=venta)
        # red = str(buscarServicios.query)
        # print (red)
        serializer = SerializerServicioCotizacion(buscarServicios, many=True)
        return Response(serializer.data)
    else:
        return Response({"no result": []})

@csrf_exempt 
@api_view(['POST'])
def ConsultarServiciosAgregados(request):
    
    venta = request.data.get('idVenta')

    if venta:
        buscarServicios = ServiciosAgregadosCotizacion.objects.filter(idVenta=venta)
        # red = str(buscarServicios.query)
        # print (red)
        serializer = SerializerServiciosAgregadosCotizacion(buscarServicios, many=True)
        return Response(serializer.data)
    else:
        return Response({"no result": []})