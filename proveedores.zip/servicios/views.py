from django.shortcuts import render
from rest_framework import viewsets
from rest_framework.authentication import BasicAuthentication
from rest_framework.permissions import IsAuthenticated

from django.views.decorators.clickjacking import xframe_options_sameorigin
from django.views.decorators.csrf import csrf_exempt
from rest_framework.views import APIView
from rest_framework.decorators import api_view

from rest_framework.response import Response
from django.db.models import Count

from .models import Services
from .serializers import ServicesSerializer, ServiciosSerializer


class ServicesViewSet(viewsets.ModelViewSet):
    # authentication_classes = (BasicAuthentication,)
    # permission_classes = (IsAuthenticated,)
    queryset = Services.objects.all()
    serializer_class = ServicesSerializer



@csrf_exempt 
@api_view(['POST', 'GET'])
def searchService(request):
    dato = request.data.get('data')

    if dato:
        servicio = Services.objects.filter(nameproduct__icontains=dato)
        # que=str(servicio.query)
        # print(que)
        serializer = ServiciosSerializer(servicio, many=True)
        return Response(serializer.data)
    else:
        return Response({"no result": []})