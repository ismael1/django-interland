from os import name

from django.urls import path, include

from servicios import views

urlpatterns = [
    path('search-service/', views.searchService), 
]